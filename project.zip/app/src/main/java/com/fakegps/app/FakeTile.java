package com.fakegps.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

public class FakeTile extends TileService {

    @Override
    public void onStartListening() {
        refresh(MockService.running);
    }

    @Override
    public void onClick() {
        if (MockService.running) {
            stopService(new Intent(this, MockService.class));
            refresh(false);
            return;
        }
        SharedPreferences sp = getSharedPreferences("p", Context.MODE_PRIVATE);
        String a = sp.getString("lat", null), b = sp.getString("lng", null);
        if (a == null || b == null) {
            Toast.makeText(this, "Buka aplikasi dan mulai sekali dulu", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            MockService.lat = Double.parseDouble(a);
            MockService.lng = Double.parseDouble(b);
            MockService.routeOn = false;
            MockService.err = "";
            Intent i = new Intent(this, MockService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            refresh(true);
        } catch (Exception e) {
            Toast.makeText(this, "Gagal memulai dari panel cepat", Toast.LENGTH_LONG).show();
        }
    }

    private void refresh(boolean on) {
        Tile t = getQsTile();
        if (t == null) return;
        t.setLabel("Pindah GPS");
        t.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.updateTile();
    }
}
