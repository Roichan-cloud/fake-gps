package com.fakegps.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import java.util.Random;

public class MockService extends Service {
    static volatile boolean running = false;
    static volatile double lat = 0, lng = 0;
    static volatile double bearing = 0;
    static volatile double speed = 0;     // m/s, dari joystick
    static volatile double curSpeed = 0;  // m/s, kecepatan yang sedang dilaporkan
    static volatile String err = "";
    static volatile boolean natural = true;

    // rute
    static volatile boolean routeOn = false;
    static volatile double routeSpeed = 1.4; // m/s
    static volatile double[] rLat = new double[0];
    static volatile double[] rLng = new double[0];
    static volatile int rIdx = 1, rDir = 1, rMode = 0; // 0 sekali, 1 bolak-balik, 2 berputar

    private static final String CH = "fakegps";
    private static final String[] PROVIDERS = {
            LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER };

    private LocationManager lm;
    private FusedLocationProviderClient fused;
    private volatile boolean fusedReady = false;
    private final Random rnd = new Random();
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean started = false;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            step();
            h.postDelayed(this, 1000);
        }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        goForeground();
        if (started) return START_NOT_STICKY;
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            for (String p : PROVIDERS) {
                try { lm.removeTestProvider(p); } catch (Exception ignored) {}
                lm.addTestProvider(p, false, false, false, false, true, true, true,
                        Criteria.POWER_LOW, Criteria.ACCURACY_FINE);
                lm.setTestProviderEnabled(p, true);
            }
        } catch (SecurityException e) {
            err = "Belum dipilih sebagai aplikasi lokasi palsu di Opsi Developer.";
            running = false;
            stopSelf();
            return START_NOT_STICKY;
        } catch (Exception e) {
            err = "Gagal memulai: " + e.getClass().getSimpleName();
            running = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        // Provider "fused" milik Google Play Services (opsional, diabaikan jika gagal)
        try {
            fused = LocationServices.getFusedLocationProviderClient(this);
            fused.setMockMode(true).addOnSuccessListener(v -> fusedReady = true);
        } catch (Throwable t) {
            fused = null;
        }
        started = true;
        running = true;
        err = "";
        h.post(tick);
        return START_NOT_STICKY;
    }

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(
                    CH, "Pindah GPS", NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, MockService.class).setAction("STOP"),
                PendingIntent.FLAG_IMMUTABLE);
        b.setContentTitle("Lokasi palsu aktif")
                .setContentText("Ketuk untuk membuka, atau tekan Berhenti")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentIntent(open)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", stop)
                .setOngoing(true);
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(1, n);
            }
        } catch (Exception e) {
            // lanjut tanpa foreground bila tidak diizinkan
        }
    }

    private void step() {
        double jit = natural ? 0.92 + rnd.nextDouble() * 0.16 : 1.0;
        if (routeOn) {
            double[] la = rLat, lo = rLng;
            int n = Math.min(la.length, lo.length);
            if (n < 2) {
                routeOn = false;
            } else {
                curSpeed = routeSpeed * jit;
                double remaining = curSpeed;
                int guard = 0;
                while (remaining > 0 && routeOn && guard++ < 50) {
                    if (rIdx < 0 || rIdx >= n) rIdx = Math.max(0, Math.min(n - 1, rIdx));
                    double tl = la[rIdx], tg = lo[rIdx];
                    double dy = (tl - lat) * 111320.0;
                    double dx = (tg - lng) * 111320.0 * Math.max(0.01, Math.cos(Math.toRadians(lat)));
                    double dist = Math.hypot(dx, dy);
                    if (dist > 0.05) bearing = (Math.toDegrees(Math.atan2(dx, dy)) + 360) % 360;
                    if (dist <= remaining) {
                        lat = tl;
                        lng = tg;
                        remaining -= dist;
                        advance(n);
                    } else {
                        double f = remaining / dist;
                        lat += (tl - lat) * f;
                        lng += (tg - lng) * f;
                        remaining = 0;
                    }
                }
                if (!routeOn) curSpeed = 0;
            }
        } else if (speed > 0) {
            curSpeed = speed * jit;
            double b = Math.toRadians(bearing);
            double dLat = curSpeed * Math.cos(b) / 111320.0;
            double cosLat = Math.max(0.01, Math.cos(Math.toRadians(lat)));
            double dLng = curSpeed * Math.sin(b) / (111320.0 * cosLat);
            lat = Math.max(-85, Math.min(85, lat + dLat));
            lng = lng + dLng;
            if (lng > 180) lng -= 360;
            if (lng < -180) lng += 360;
        } else {
            curSpeed = 0;
        }
        push();
    }

    private void advance(int n) {
        if (rMode == 0) {
            if (rIdx >= n - 1) routeOn = false;
            else rIdx++;
        } else if (rMode == 1) {
            int next = rIdx + rDir;
            if (next >= n) { rDir = -1; next = n - 2; }
            else if (next < 0) { rDir = 1; next = 1; }
            rIdx = next;
        } else {
            rIdx = (rIdx + 1) % n;
        }
    }

    private Location mk(String p, double la, double lo, float acc) {
        Location l = new Location(p);
        l.setLatitude(la);
        l.setLongitude(lo);
        l.setAltitude(10);
        l.setAccuracy(acc);
        l.setSpeed((float) curSpeed);
        l.setBearing((float) bearing);
        l.setTime(System.currentTimeMillis());
        l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
        return l;
    }

    private void push() {
        double la = lat, lo = lng;
        float acc = 5f;
        if (natural) {
            la += (rnd.nextDouble() - 0.5) * 2 * 0.8 / 111320.0;
            lo += (rnd.nextDouble() - 0.5) * 2 * 0.8
                    / (111320.0 * Math.max(0.01, Math.cos(Math.toRadians(lat))));
            acc = 3f + rnd.nextFloat() * 6f;
        }
        for (String p : PROVIDERS) {
            try {
                lm.setTestProviderLocation(p, mk(p, la, lo, acc));
            } catch (Exception e) {
                err = "Gagal kirim lokasi: " + e.getClass().getSimpleName();
            }
        }
        if (fusedReady && fused != null) {
            try { fused.setMockLocation(mk("fused", la, lo, acc)); } catch (Throwable ignored) {}
        }
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(tick);
        try {
            SharedPreferences sp = getSharedPreferences("p", Context.MODE_PRIVATE);
            sp.edit().putString("lat", String.valueOf(lat))
                    .putString("lng", String.valueOf(lng)).apply();
        } catch (Exception ignored) {}
        if (lm != null) {
            for (String p : PROVIDERS) {
                try { lm.removeTestProvider(p); } catch (Exception ignored) {}
            }
        }
        if (fused != null) {
            try { fused.setMockMode(false); } catch (Throwable ignored) {}
        }
        started = false;
        running = false;
        routeOn = false;
        speed = 0;
        curSpeed = 0;
        super.onDestroy();
    }
}
