package com.fakegps.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;

public class MockService extends Service {
    static volatile boolean running = false;
    static volatile double lat = -6.2, lng = 106.816666;
    static volatile double bearing = 0;
    static volatile double speed = 0; // m/s
    static volatile String err = "";

    private static final String CH = "fakegps";
    private static final String[] PROVIDERS = {
            LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER };

    private LocationManager lm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean started = false;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            step();
            h.postDelayed(this, 1000);
        }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        goForeground();
        if (started) return START_STICKY;
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            for (String p : PROVIDERS) {
                try { lm.removeTestProvider(p); } catch (Exception ignored) {}
                lm.addTestProvider(p, false, false, false, false, true, true, true,
                        Criteria.POWER_LOW, Criteria.ACCURACY_FINE);
                lm.setTestProviderEnabled(p, true);
            }
        } catch (SecurityException e) {
            err = "Belum dipilih sebagai aplikasi lokasi palsu. Buka Opsi Developer lalu pilih Fake GPS.";
            running = false;
            stopSelf();
            return START_NOT_STICKY;
        } catch (Exception e) {
            err = "Gagal memulai: " + e.getClass().getSimpleName();
            running = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        started = true;
        running = true;
        err = "";
        h.post(tick);
        return START_STICKY;
    }

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(
                    CH, "Fake GPS", NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setContentTitle("Fake GPS aktif")
                .setContentText("Lokasi palsu sedang dikirim")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setOngoing(true);
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(1, n);
            }
        } catch (Exception e) {
            // lanjut tanpa foreground jika izin belum diberikan
        }
    }

    private void step() {
        if (speed > 0) {
            double b = Math.toRadians(bearing);
            double dLat = speed * Math.cos(b) / 111320.0;
            double cosLat = Math.max(0.01, Math.cos(Math.toRadians(lat)));
            double dLng = speed * Math.sin(b) / (111320.0 * cosLat);
            lat = Math.max(-85, Math.min(85, lat + dLat));
            lng = lng + dLng;
            if (lng > 180) lng -= 360;
            if (lng < -180) lng += 360;
        }
        push();
    }

    private void push() {
        for (String p : PROVIDERS) {
            try {
                Location l = new Location(p);
                l.setLatitude(lat);
                l.setLongitude(lng);
                l.setAltitude(10);
                l.setAccuracy(5f);
                l.setSpeed((float) speed);
                l.setBearing((float) bearing);
                l.setTime(System.currentTimeMillis());
                l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
                lm.setTestProviderLocation(p, l);
            } catch (Exception e) {
                err = "Gagal kirim lokasi: " + e.getClass().getSimpleName();
            }
        }
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(tick);
        if (lm != null) {
            for (String p : PROVIDERS) {
                try { lm.removeTestProvider(p); } catch (Exception ignored) {}
            }
        }
        started = false;
        running = false;
        speed = 0;
        super.onDestroy();
    }
}
