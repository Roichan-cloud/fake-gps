package com.fakegps.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView wv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        askPermissions();

        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        wv.setWebChromeClient(new WebChromeClient());
        wv.setWebViewClient(new WebViewClient());
        wv.addJavascriptInterface(new Bridge(), "Android");
        wv.loadDataWithBaseURL("https://fakegps.app/", readAsset("index.html"),
                "text/html", "UTF-8", null);
    }

    private void askPermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.POST_NOTIFICATIONS}, 1);
            } else {
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
        }
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "<h3>Gagal memuat antarmuka</h3>";
        }
    }

    @Override
    public void onBackPressed() {
        if (wv != null && wv.canGoBack()) wv.goBack();
        else super.onBackPressed();
    }

    class Bridge {
        @JavascriptInterface
        public void start(double lat, double lng) {
            MockService.lat = lat;
            MockService.lng = lng;
            MockService.err = "";
            Context c = MainActivity.this;
            Intent i = new Intent(c, MockService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        }

        @JavascriptInterface
        public void stop() {
            stopService(new Intent(MainActivity.this, MockService.class));
        }

        @JavascriptInterface
        public void setMove(double bearing, double speedKmh) {
            MockService.bearing = bearing;
            MockService.speed = Math.max(0, speedKmh) / 3.6;
        }

        @JavascriptInterface
        public String getState() {
            return String.format(Locale.US,
                    "{\"running\":%b,\"lat\":%.7f,\"lng\":%.7f,\"err\":\"%s\"}",
                    MockService.running, MockService.lat, MockService.lng,
                    MockService.err.replace("\"", "'"));
        }

        @JavascriptInterface
        public void openDev() {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }
        }
    }
}
