package com.fakegps.app;

import android.Manifest;
import android.app.Activity;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView wv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        askPermissions();

        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        wv.setWebChromeClient(new WebChromeClient());
        wv.setWebViewClient(new WebViewClient());
        wv.addJavascriptInterface(new Bridge(), "Android");
        wv.loadDataWithBaseURL("https://fakegps.app/", readAsset("index.html"),
                "text/html", "UTF-8", null);
    }

    private void askPermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.POST_NOTIFICATIONS}, 1);
            } else {
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        fetchReal();
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "<h3>Gagal memuat antarmuka</h3>";
        }
    }

    @Override
    public void onBackPressed() {
        if (wv != null && wv.canGoBack()) wv.goBack();
        else super.onBackPressed();
    }

    // ---------- Lokasi asli perangkat ----------
    private boolean isMock(Location l) {
        if (Build.VERSION.SDK_INT >= 31) return l.isMock();
        return l.isFromMockProvider();
    }

    private void sendReal(Location l) {
        if (l == null || isMock(l) || wv == null) return;
        final String js = String.format(Locale.US,
                "window.onReal&&window.onReal(%.6f,%.6f)", l.getLatitude(), l.getLongitude());
        wv.post(() -> wv.evaluateJavascript(js, null));
    }

    private class OneShot implements LocationListener {
        @Override public void onLocationChanged(Location l) { sendReal(l); }
        @Override public void onStatusChanged(String p, int s, Bundle b) {}
        @Override public void onProviderEnabled(String p) {}
        @Override public void onProviderDisabled(String p) {}
    }

    private void fetchReal() {
        if (MockService.running) return;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Location best = null;
        String[] all = {LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER,
                LocationManager.PASSIVE_PROVIDER};
        for (String p : all) {
            try {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && !isMock(l) && (best == null || l.getTime() > best.getTime())) best = l;
            } catch (Exception ignored) {}
        }
        if (best != null) sendReal(best);
        String[] live = {LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER};
        for (String p : live) {
            try {
                if (!lm.isProviderEnabled(p)) continue;
                if (Build.VERSION.SDK_INT >= 30) {
                    lm.getCurrentLocation(p, null, getMainExecutor(), loc -> sendReal(loc));
                } else {
                    lm.requestSingleUpdate(p, new OneShot(), Looper.getMainLooper());
                }
            } catch (Exception ignored) {}
        }
    }

    // ---------- Jembatan ke JavaScript ----------
    private void launch() {
        Intent i = new Intent(this, MockService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Exception e) {
            try {
                startService(i);
            } catch (Exception e2) {
                MockService.err = "Tidak bisa menjalankan layanan: " + e2.getClass().getSimpleName();
            }
        }
    }

    private void savePos(double lat, double lng) {
        SharedPreferences sp = getSharedPreferences("p", Context.MODE_PRIVATE);
        sp.edit().putString("lat", String.valueOf(lat))
                .putString("lng", String.valueOf(lng)).apply();
    }

    class Bridge {
        @JavascriptInterface
        public void start(double lat, double lng) {
            MockService.routeOn = false;
            MockService.lat = lat;
            MockService.lng = lng;
            MockService.err = "";
            savePos(lat, lng);
            launch();
        }

        @JavascriptInterface
        public void stop() {
            stopService(new Intent(MainActivity.this, MockService.class));
        }

        @JavascriptInterface
        public void setMove(double bearing, double speedKmh) {
            if (MockService.routeOn && speedKmh > 0) MockService.routeOn = false;
            MockService.bearing = bearing;
            MockService.speed = Math.max(0, speedKmh) / 3.6;
        }

        @JavascriptInterface
        public void startRoute(String json, double speedKmh, int mode) {
            try {
                JSONArray a = new JSONArray(json);
                int n = a.length();
                if (n < 2) return;
                double[] la = new double[n], lo = new double[n];
                for (int i = 0; i < n; i++) {
                    JSONArray p = a.getJSONArray(i);
                    la[i] = p.getDouble(0);
                    lo[i] = p.getDouble(1);
                }
                MockService.routeOn = false;
                MockService.rLat = la;
                MockService.rLng = lo;
                MockService.lat = la[0];
                MockService.lng = lo[0];
                MockService.rIdx = 1;
                MockService.rDir = 1;
                MockService.rMode = mode;
                MockService.routeSpeed = Math.max(0.1, speedKmh) / 3.6;
                MockService.speed = 0;
                MockService.err = "";
                savePos(la[0], lo[0]);
                MockService.routeOn = true;
                launch();
            } catch (Exception e) {
                MockService.err = "Data rute tidak valid";
            }
        }

        @JavascriptInterface
        public void stopRoute() { MockService.routeOn = false; }

        @JavascriptInterface
        public void setRouteSpeed(double speedKmh) {
            MockService.routeSpeed = Math.max(0.1, speedKmh) / 3.6;
        }

        @JavascriptInterface
        public void setNatural(boolean on) { MockService.natural = on; }

        @JavascriptInterface
        public void fetchReal() {
            runOnUiThread(() -> MainActivity.this.fetchReal());
        }

        @JavascriptInterface
        public String getState() {
            return String.format(Locale.US,
                    "{\"running\":%b,\"route\":%b,\"lat\":%.7f,\"lng\":%.7f,\"err\":\"%s\"}",
                    MockService.running, MockService.routeOn,
                    MockService.lat, MockService.lng,
                    MockService.err.replace("\"", "'"));
        }

        @JavascriptInterface
        public String getStatus() {
            boolean loc = Build.VERSION.SDK_INT < 23 || checkSelfPermission(
                    Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            boolean notif = true;
            if (Build.VERSION.SDK_INT >= 33) {
                notif = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED;
            }
            boolean mock = true;
            try {
                AppOpsManager ao = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
                mock = ao.checkOp("android:mock_location", Process.myUid(), getPackageName())
                        == AppOpsManager.MODE_ALLOWED;
            } catch (Exception ignored) {}
            boolean dev = true;
            try {
                dev = Settings.Global.getInt(getContentResolver(),
                        Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1;
            } catch (Exception ignored) {}
            return String.format(Locale.US,
                    "{\"loc\":%b,\"notif\":%b,\"mock\":%b,\"dev\":%b}", loc, notif, mock, dev);
        }

        @JavascriptInterface
        public void openDev() {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }
        }

        @JavascriptInterface
        public void openAppSettings() {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ignored) {}
        }
    }
}
